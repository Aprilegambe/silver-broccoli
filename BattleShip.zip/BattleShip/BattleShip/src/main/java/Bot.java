import java.awt.*;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import javax.swing.*;

public class Bot extends Giocatore {
    private Random random;
    private boolean difficile;
    private Deque<Point> bersagliAdiacenti;
    private boolean[][] celleColpite;

    public Bot(JButton[][] pulsantiGriglia, boolean difficile) {
        super(pulsantiGriglia);
        this.random = new Random();
        this.difficile = difficile;
        this.bersagliAdiacenti = new LinkedList<>();
        this.celleColpite = new boolean[10][10];
    }

    @Override
    public boolean posizionaNave(Nave nave, int x, int y, boolean orizzontale) {
        // Non colorare le celle del bot
        if (nave.posiziona(x, y, orizzontale, griglia)) {
            navi.add(nave);
            return true;
        }
        return false;
    }

    public void posizionaNaviAutomaticamente() {
        int[] dimensioniNavi = {5, 4, 3, 3, 2};
        for (int lunghezza : dimensioniNavi) {
            boolean posizionata = false;
            while (!posizionata) {
                int x = random.nextInt(10);
                int y = random.nextInt(10);
                boolean orizzontale = random.nextBoolean();
                Nave nave = new Nave(lunghezza);
                if (posizionaNave(nave, x, y, orizzontale)) {
                    posizionata = true;
                }
            }
        }
    }

    public Point effettuaAttacco() {
        Point bersaglio = null;

        if (difficile && !bersagliAdiacenti.isEmpty()) {
            do {
                bersaglio = bersagliAdiacenti.pollFirst();
            } while (bersaglio != null && celleColpite[bersaglio.x][bersaglio.y]);
        }

        if (bersaglio == null) {
            int x, y;
            do {
                x = random.nextInt(10);
                y = random.nextInt(10);
            } while (celleColpite[x][y]);
            bersaglio = new Point(x, y);
        }
        celleColpite[bersaglio.x][bersaglio.y] = true;
        return bersaglio;
    }

    public void registraEsitoAttacco(Point punto, boolean colpito) {
        if (!difficile) return;

        if (colpito) {
            for (Point adiacente : getAdiacentiNonColpite(punto)) {
                bersagliAdiacenti.addLast(adiacente);
            }
        }
    }

    private List<Point> getAdiacentiNonColpite(Point p) {
        List<Point> adiacenti = new LinkedList<>();
        int x = p.x, y = p.y;
        int[][] dirs = {{-1,0}, {1,0}, {0,-1}, {0,1}};
        for (int[] d : dirs) {
            int nx = x + d[0], ny = y + d[1];
            if (nx >= 0 && nx < 10 && ny >= 0 && ny < 10 && !celleColpite[nx][ny]) {
                adiacenti.add(new Point(nx, ny));
            }
        }
        return adiacenti;
    }
}