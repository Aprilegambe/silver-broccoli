import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.util.List;

/**
 * Classe che rappresenta l'intelligenza artificiale del gioco. Il bot può essere configurato in modalità facile o difficile e gestisce gli attacchi automaticamente.
 * @field random (Random)
 * @field difficile (boolean)
 * @field bersagliAdiacenti (Deque<Point>)
 * @field celleColpite (boolean[][])
 * @field true (return)
 * @field false (return)
 * @field bersaglio (return)
 * @field adiacenti (return)
 * @method Bot(JButton[][] pulsantiGriglia, boolean difficile) : public
 * @method Random() : new
 * @method posizionaNave(Nave nave, int x, int y, boolean orizzontale) : boolean
 * @method posizionaNaviAutomaticamente() : void
 * @method Nave(lunghezza) : new
 * @method effettuaAttacco() : Point
 * @method Point(nx, ny) : new
 * @method Point(x, y) : new
 * @method registraEsitoAttacco(Point punto, boolean colpito) : void
 * @method Point(punto.x - precedente.x, punto.y - precedente.y) : new
 * @method getAdiacentiNonColpite(Point p) : List<Point>
 */
public class Bot extends Giocatore {
    private Random random;
    private boolean difficile;
    private Deque<Point> bersagliAdiacenti;
    private boolean[][] celleColpite;

    // Variabili per attacchi mirati
    private Point ultimoColpo = null;
    private Point direzioneAttacco = null;

    public Bot(JButton[][] pulsantiGriglia, boolean difficile) {
        super(pulsantiGriglia);
        this.random = new Random();
        this.difficile = difficile;
        this.bersagliAdiacenti = new LinkedList<>();
        this.celleColpite = new boolean[10][10];
    }

    @Override
    public boolean posizionaNave(Nave nave, int x, int y, boolean orizzontale) {
        if (nave.posiziona(x, y, orizzontale, griglia)) {
            navi.add(nave);
            return true;
        }
        return false;
    }

    public void posizionaNaviAutomaticamente() {
        int[] dimensioniNavi = {5, 4, 3, 3, 2};
        for (int lunghezza : dimensioniNavi) {
            boolean posizionata = false;
            while (!posizionata) {
                int x = random.nextInt(10);
                int y = random.nextInt(10);
                boolean orizzontale = random.nextBoolean();
                Nave nave = new Nave(lunghezza);
                if (posizionaNave(nave, x, y, orizzontale)) {
                    posizionata = true;
                }
            }
        }
    }

    public Point effettuaAttacco() {
        Point bersaglio = null;

        // Prova a colpire in linea retta se abbiamo direzione
        if (difficile && direzioneAttacco != null && ultimoColpo != null) {
            int dx = direzioneAttacco.x;
            int dy = direzioneAttacco.y;
            int nx = ultimoColpo.x + dx;
            int ny = ultimoColpo.y + dy;

            if (nx >= 0 && nx < 10 && ny >= 0 && ny < 10 && !celleColpite[nx][ny]) {
                bersaglio = new Point(nx, ny);
            } else {
                direzioneAttacco = null;  // direzione non valida
            }
        }

        // Altrimenti prova colpi adiacenti
        if (difficile && bersaglio == null && !bersagliAdiacenti.isEmpty()) {
            do {
                bersaglio = bersagliAdiacenti.pollFirst();
            } while (bersaglio != null && celleColpite[bersaglio.x][bersaglio.y]);
        }

        // Altrimenti colpo casuale con strategia a scacchiera
        if (bersaglio == null) {
            int x, y;
            do {
                x = random.nextInt(10);
                y = random.nextInt(10);
            } while (celleColpite[x][y] || ((x + y) % 2 != 0 && difficile));
            bersaglio = new Point(x, y);
        }

        celleColpite[bersaglio.x][bersaglio.y] = true;
        ultimoColpo = bersaglio;
        return bersaglio;
    }

    public void registraEsitoAttacco(Point punto, boolean colpito) {
        if (!difficile) return;

        if (colpito) {
            // Imposta direzione se possibile
            if (ultimoColpo != null && !bersagliAdiacenti.isEmpty()) {
                Point precedente = bersagliAdiacenti.peekLast();
                if (precedente != null) {
                    direzioneAttacco = new Point(punto.x - precedente.x, punto.y - precedente.y);
                }
            }

            for (Point adiacente : getAdiacentiNonColpite(punto)) {
                bersagliAdiacenti.addLast(adiacente);
            }
        } else {
            direzioneAttacco = null;
        }
    }

    private List<Point> getAdiacentiNonColpite(Point p) {
        List<Point> adiacenti = new LinkedList<>();
        int x = p.x, y = p.y;
        int[][] dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] d : dirs) {
            int nx = x + d[0], ny = y + d[1];
            if (nx >= 0 && nx < 10 && ny >= 0 && ny < 10 && !celleColpite[nx][ny]) {
                adiacenti.add(new Point(nx, ny));
            }
        }
        return adiacenti;
    }
}
