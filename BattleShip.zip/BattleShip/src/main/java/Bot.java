/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author antonio
 */
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.*;

public class Bot extends Giocatore {
    private Random random;
    private boolean difficile; // Modalità di difficoltà
    private List<Point> bersagliAdiacenti; // Per modalità difficile

    public Bot(JButton[][] pulsantiGriglia, boolean difficile) {
        super(pulsantiGriglia);
        this.random = new Random();
        this.difficile = difficile;
        this.bersagliAdiacenti = new ArrayList<>();
    }

    public Point effettuaAttacco() {
        if (difficile && !bersagliAdiacenti.isEmpty()) {
            // Modalità difficile: spara ai bersagli adiacenti
            return bersagliAdiacenti.remove(0);
        }
        // Modalità facile o nessun bersaglio adiacente: attacco casuale
        int x = random.nextInt(10);
        int y = random.nextInt(10);
        return new Point(x, y);
    }

    public void registraEsitoAttacco(Point punto, boolean colpito) {
        if (difficile && colpito) {
            // Aggiungi bersagli adiacenti
            int x = punto.x;
            int y = punto.y;
            if (x > 0) bersagliAdiacenti.add(new Point(x - 1, y));
            if (x < 9) bersagliAdiacenti.add(new Point(x + 1, y));
            if (y > 0) bersagliAdiacenti.add(new Point(x, y - 1));
            if (y < 9) bersagliAdiacenti.add(new Point(x, y + 1));
        }
    }

    public void posizionaNaviAutomaticamente() {
        int[] dimensioniNavi = {5, 4, 3, 3, 2};
        for (int lunghezza : dimensioniNavi) {
            boolean posizionata = false;
            while (!posizionata) {
                int x = random.nextInt(10);
                int y = random.nextInt(10);
                boolean orizzontale = random.nextBoolean();
                Nave nave = new Nave(lunghezza);
                if (posizionaNave(nave, x, y, orizzontale)) {
                    posizionata = true;
                }
            }
        }
    }
}
