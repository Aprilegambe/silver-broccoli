import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

/**
 * Classe che rappresenta un giocatore umano, gestisce il posizionamento delle navi e riceve attacchi.
 * @field pulsantiGriglia (JButton[][])
 * @field true (return)
 * @field false (return)
 * @field true (return)
 * @field false (return)
 * @field true (return)
 * @field false (return)
 * @field navi (return)
 * @field false (return)
 * @field true (return)
 * @method Giocatore(JButton[][] pulsantiGriglia) : public
 * @method posizionaNave(Nave nave, int x, int y, boolean orizzontale) : boolean
 * @method haNave(int x, int y) : boolean
 * @method riceviAttacco(int x, int y) : boolean
 * @method Color(10, 30, 90) : new
 * @method haPerso() : boolean
 * @method getNavi() : List<Nave>
 * @method puoPosizionare(Nave nave, int x, int y, boolean orizzontale) : boolean
 */
public class Giocatore {
    protected boolean[][] griglia = new boolean[10][10];
    protected JButton[][] pulsantiGriglia;
    protected List<Nave> navi = new ArrayList<>();

    public Giocatore(JButton[][] pulsantiGriglia) {
        this.pulsantiGriglia = pulsantiGriglia;
    }

    public boolean posizionaNave(Nave nave, int x, int y, boolean orizzontale) {
        if (nave.posiziona(x, y, orizzontale, griglia)) {
            navi.add(nave);
            // Colora solo per il giocatore umano!
            for (Point punto : nave.getPosizioni()) {
                pulsantiGriglia[punto.x][punto.y].setBackground(Color.GRAY);
            }
            return true;
        }
        return false;
    }

    public boolean haNave(int x, int y) {
        for (Nave nave : navi) {
            for (Point p : nave.getPosizioni()) {
                if (p.x == x && p.y == y) return true;
            }
        }
        return false;
    }

    public boolean riceviAttacco(int x, int y) {
    for (Nave nave : navi) {
        for (Point p : nave.getPosizioni()) {
            if (p.x == x && p.y == y && !nave.isAffondata()) {
                nave.subisciColpo();
                pulsantiGriglia[x][y].setBackground(Color.RED);
                if (nave.isAffondata()) {
                    Color bluScuro = new Color(10, 30, 90);
                    for (Point pos : nave.getPosizioni()) {
                        pulsantiGriglia[pos.x][pos.y].setBackground(bluScuro);
                    }
                }
                griglia[x][y] = false;
                return true;
            }
        }
    }
    pulsantiGriglia[x][y].setBackground(Color.WHITE);
    return false;
}


    public boolean haPerso() {
        return navi.stream().allMatch(Nave::isAffondata);
    }

    public List<Nave> getNavi() {
        return navi;
    }
    
    public boolean puoPosizionare(Nave nave, int x, int y, boolean orizzontale) {
        for (int i = 0; i < nave.getLunghezza(); i++) {
            int nx = orizzontale ? x + i : x;
            int ny = orizzontale ? y : y + i;
            if (nx >= 10 || ny >= 10 || griglia[nx][ny]) {
                return false; 
            }
        }
        return true;
    }

}