/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author antonio
 */
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Giocatore {
    private boolean[][] griglia; // Griglia 10x10
    private JButton[][] pulsantiGriglia; // Pulsanti per la GUI
    private List<Nave> navi; // Lista di navi posizionate

    public Giocatore(JButton[][] pulsantiGriglia) {
        this.griglia = new boolean[10][10]; // Inizializza la griglia vuota
        this.pulsantiGriglia = pulsantiGriglia;
        this.navi = new ArrayList<>();
    }

    public boolean posizionaNave(Nave nave, int x, int y, boolean orizzontale) {
        if (nave.posiziona(x, y, orizzontale, griglia)) {
            navi.add(nave);
            for (Point punto : nave.getPosizioni()) {
                pulsantiGriglia[punto.x][punto.y].setBackground(Color.BLUE); // Evidenzia la nave
            }
            return true;
        }
        return false;
    }

    public boolean riceviAttacco(int x, int y) {
        if (griglia[x][y]) {
            griglia[x][y] = false; // Segna come colpito
            pulsantiGriglia[x][y].setBackground(Color.RED); // Cambia colore per hit
            return true; // Colpo a segno
        }
        pulsantiGriglia[x][y].setBackground(Color.GRAY); // Cambia colore per miss
        return false; // Colpo mancato
    }

    public boolean haPerso() {
        return navi.stream().allMatch(Nave::isAffondata);
    }

    public List<Nave> getNavi() {
        return navi;
    }
    
    public boolean puoPosizionare(Nave nave, int x, int y, boolean orizzontale) {
        for (int i = 0; i < nave.getLunghezza(); i++) {
            int nx = orizzontale ? x + i : x;
            int ny = orizzontale ? y : y + i;
            if (nx >= 10 || ny >= 10 || griglia[nx][ny]) {
                return false; 
            }
        }
        return true;
    }

    public boolean haNave(int x, int y) {
        return griglia[x][y];
    }
}
