/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author antonio
 */
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Nave {

    private int lunghezza;
    private List<Point> posizioni; // Posizioni occupate dalla nave
    private int colpiSubiti;

    public Nave(int lunghezza) {
        this.lunghezza = lunghezza;
        this.posizioni = new ArrayList<>();
        this.colpiSubiti = 0;
    }

    public boolean posiziona(int x, int y, boolean orizzontale, boolean[][] griglia) {
        List<Point> tempPosizioni = new ArrayList<>();
        if (orizzontale) {
            if (x + lunghezza > 10) {
                return false; // Esce dalla griglia
            }
            for (int i = 0; i < lunghezza; i++) {
                if (griglia[x + i][y]) {
                    return false; // Già occupata
                }
                tempPosizioni.add(new Point(x + i, y));
            }
        } else {
            if (y + lunghezza > 10) {
                return false; // Esce dalla griglia
            }
            for (int i = 0; i < lunghezza; i++) {
                if (griglia[x][y + i]) {
                    return false; // Già occupata
                }
                tempPosizioni.add(new Point(x, y + i));
            }
        }
        for (Point punto : tempPosizioni) {
            griglia[punto.x][punto.y] = true; // Segna come occupata
        }
        posizioni.addAll(tempPosizioni);
        return true;
    }

    public void subisciColpo() {
        colpiSubiti++;
    }

    public boolean isAffondata() {
        return colpiSubiti >= lunghezza;
    }

    public List<Point> getPosizioni() {
        return posizioni;
    }

    public int getLunghezza() {
        return lunghezza;
    }
}
