import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe che rappresenta una nave nel gioco. Tiene traccia della lunghezza, delle posizioni occupate sulla griglia e dello stato (colpita o affondata).
 * @field lunghezza (int)
 * @field lunghezza (<)
 * @field false (return)
 * @field true (return)
 * @field posizioni (return)
 * @field lunghezza (return)
 * @method Nave(int lunghezza) : public
 * @method posiziona(int x, int y, boolean orizzontale, boolean[][] griglia) : boolean
 * @method subisciColpo() : void
 * @method isAffondata() : boolean
 * @method getPosizioni() : List<Point>
 * @method getLunghezza() : int
 */
public class Nave {
    private int lunghezza;
    private int colpiSubiti = 0;
    private List<Point> posizioni = new ArrayList<>();

    public Nave(int lunghezza) {
        this.lunghezza = lunghezza;
    }

    public boolean posiziona(int x, int y, boolean orizzontale, boolean[][] griglia) {
        posizioni.clear();
        for (int i = 0; i < lunghezza; i++) {
            int nx = orizzontale ? x + i : x;
            int ny = orizzontale ? y : y + i;
            if (nx >= 10 || ny >= 10 || griglia[nx][ny]) return false;
            posizioni.add(new Point(nx, ny));
        }
        for (Point p : posizioni) {
            griglia[p.x][p.y] = true;
        }
        return true;
    }

    public void subisciColpo() {
        colpiSubiti++;
    }

    public boolean isAffondata() {
        return colpiSubiti >= lunghezza;
    }

    public List<Point> getPosizioni() {
        return posizioni;
    }

    public int getLunghezza() {
        return lunghezza;
    }
}