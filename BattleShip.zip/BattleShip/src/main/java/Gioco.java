
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author antonio
 */


    public class Gioco extends javax.swing.JFrame {
    private final boolean difficolta;
    private Giocatore giocatore;
    private Bot bot;
    private boolean orizzontale = true;
    private int[] dimensioniNavi = {5, 4, 3, 3, 2};
    private int indiceNaveCorrente = 0;
    private int colpiGiocatore = 0;
    private int colpiBot = 0;
    private JButton[][] grigliaGiocatore;
    private JButton[][] grigliaBot;

    public Gioco(boolean diff) {
        initComponents();
        difficolta = diff;

        setTitle(difficolta ? "𝗚𝗶𝗼𝗰𝗼 -> 𝗗𝗶𝗳𝗳𝗶𝗰𝗶𝗹𝗲" : "𝗚𝗶𝗼𝗰𝗼 -> 𝗙𝗮𝗰𝗶𝗹𝗲");
        jTextAreaSideBar.append("Posiziona le tue navi: dimensione attuale " + dimensioniNavi[indiceNaveCorrente] + "\n");

        grigliaGiocatore = new JButton[10][10];
        grigliaBot = new JButton[10][10];
        creaGriglia(grigliaGiocatore, true, jPanelGrigliaGiocatore);
        creaGriglia(grigliaBot, false, jPanelGrigliaBot);

        giocatore = new Giocatore(grigliaGiocatore);
        bot = new Bot(grigliaBot, difficolta);
        bot.posizionaNaviAutomaticamente();

        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("R"), "ruota");
        getRootPane().getActionMap().put("ruota", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                orizzontale = !orizzontale;
                jTextAreaSideBar.append("Orientamento ruotato a " + (orizzontale ? "orizzontale" : "verticale") + "\n");
            }
        });
    }

    public void creaGriglia(JButton[][] griglia, boolean isGiocatore, JPanel panel) {
        panel.removeAll();      
        panel.setLayout(new GridLayout(10, 10));
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                JButton btn = new JButton();
                btn.setPreferredSize(new Dimension(30, 30));
                btn.setOpaque(true);
                btn.setBorderPainted(true);
                btn.setBackground(Color.CYAN); // Colore di sfondo iniziale
                griglia[i][j] = btn;

                final int x = i;
                final int y = j;

                if (isGiocatore) {
                    btn.addActionListener(e -> posizionaNave(x, y));
                    btn.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseEntered(MouseEvent e) {
                            mostraPreview(x, y, true);
                        }

                        @Override
                        public void mouseExited(MouseEvent e) {
                            mostraPreview(x, y, false);
                        }
                    });
                } else {
                    btn.addActionListener(e -> provaAttacco(x, y));
                }

                panel.add(btn);
            }
        }
        panel.revalidate();
        panel.repaint();
    }

    public void mostraPreview(int x, int y, boolean mostra) {
        if (indiceNaveCorrente >= dimensioniNavi.length) return;

        int lunghezza = dimensioniNavi[indiceNaveCorrente];
        for (int i = 0; i < lunghezza; i++) {
            int nx = orizzontale ? x + i : x;
            int ny = orizzontale ? y : y + i;

            if (nx < 10 && ny < 10) {
                JButton cella = grigliaGiocatore[nx][ny];
                if (mostra) {
                    cella.setBackground(Color.GREEN); // Mostra preview in verde
                } else {
                    cella.setBackground(Color.CYAN); // Ripristina colore originale
                    if (giocatore.haNave(nx, ny)) {
                        cella.setBackground(Color.GRAY); // Mantieni colore grigio per le navi
                    }
                }
            }
        }
    }

    public void posizionaNave(int x, int y) {
        if (indiceNaveCorrente >= dimensioniNavi.length) {
            jTextAreaSideBar.append("Tutte le navi sono state posizionate\n");
            return;
        }

        Nave nave = new Nave(dimensioniNavi[indiceNaveCorrente]);
        if (giocatore.posizionaNave(nave, x, y, orizzontale)) {
            jTextAreaSideBar.append("Nave posizionata: dimensione " + dimensioniNavi[indiceNaveCorrente] + "\n");
            indiceNaveCorrente++;
            for (int i = 0; i < nave.getLunghezza(); i++) {
                int nx = orizzontale ? x + i : x;
                int ny = orizzontale ? y : y + i;
                grigliaGiocatore[nx][ny].setBackground(Color.GRAY); // Imposta colore grigio per la nave
            }
            if (indiceNaveCorrente < dimensioniNavi.length) {
                jTextAreaSideBar.append("Posiziona la prossima nave: dimensione " + dimensioniNavi[indiceNaveCorrente] + "\n");
            }
        } else {
            jTextAreaSideBar.append("Posizionamento non valido\n");
        }
    }

    public void provaAttacco(int x, int y) {
        boolean colpito = bot.riceviAttacco(x, y);
        jTextAreaSideBar.append(colpito ? "Colpo a segno!\n" : "Colpo mancato!\n");

        if (colpito) {
            colpiGiocatore++;
            grigliaBot[x][y].setBackground(Color.RED); // Rosso per colpo a segno
            verificaFinePartita();
        } else {
            grigliaBot[x][y].setBackground(Color.WHITE); // Bianco per colpo mancato
        }

        Point attaccoBot = bot.effettuaAttacco();
        boolean colpoBot = giocatore.riceviAttacco(attaccoBot.x, attaccoBot.y);
        jTextAreaSideBar.append(colpoBot ? "Il bot ha colpito!\n" : "Il bot ha mancato!\n");

        if (colpoBot) {
            colpiBot++;
            grigliaGiocatore[attaccoBot.x][attaccoBot.y].setBackground(Color.RED); // Rosso per colpo a segno
            verificaFinePartita();
        } else {
            grigliaGiocatore[attaccoBot.x][attaccoBot.y].setBackground(Color.WHITE); // Bianco per colpo mancato
        }
    }

    public void verificaFinePartita() {
        if (colpiGiocatore >= 17) {
            finePartita(true);
        } else if (colpiBot >= 17) {
            finePartita(false);
        }
    }

    public void finePartita(boolean vittoria) {
        String messaggio = vittoria ? "Hai vinto! Il bot ha perso." : "Hai perso! Il bot ha vinto.";
        jTextAreaSideBar.append(messaggio + "\n");
        JOptionPane.showMessageDialog(this, messaggio);
        System.exit(0);
    }

    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelGrigliaBot = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanelGrigliaGiocatore = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPaneSideBar = new javax.swing.JScrollPane();
        jTextAreaSideBar = new javax.swing.JTextArea();
        jButtonReset = new javax.swing.JButton();
        jButtonMenu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setResizable(false);

        jPanelGrigliaBot.setBackground(new java.awt.Color(51, 255, 51));
        jPanelGrigliaBot.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanelGrigliaBot.setPreferredSize(new java.awt.Dimension(300, 300));
        jPanelGrigliaBot.setLayout(new java.awt.GridLayout(1, 0));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Griglia.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanelGrigliaBot.add(jLabel1);

        jPanelGrigliaGiocatore.setBackground(new java.awt.Color(102, 255, 102));
        jPanelGrigliaGiocatore.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanelGrigliaGiocatore.setPreferredSize(new java.awt.Dimension(300, 300));
        jPanelGrigliaGiocatore.setRequestFocusEnabled(false);
        jPanelGrigliaGiocatore.setLayout(new java.awt.GridLayout(1, 0));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Griglia.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanelGrigliaGiocatore.add(jLabel2);

        jScrollPaneSideBar.setBackground(new java.awt.Color(51, 51, 51));
        jScrollPaneSideBar.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jTextAreaSideBar.setColumns(20);
        jTextAreaSideBar.setRows(5);
        jScrollPaneSideBar.setViewportView(jTextAreaSideBar);

        jButtonReset.setPreferredSize(new java.awt.Dimension(200, 29));
        jButtonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonResetActionPerformed(evt);
            }
        });

        jButtonMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelGrigliaBot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanelGrigliaGiocatore, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButtonReset, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPaneSideBar))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPaneSideBar, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonReset, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanelGrigliaBot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanelGrigliaGiocatore, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   

    private void jButtonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonResetActionPerformed
        this.dispose();
        Gioco gioco = new Gioco(difficolta);
        gioco.setVisible(true);
    }//GEN-LAST:event_jButtonResetActionPerformed

    private void jButtonMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenuActionPerformed
        // TODO add your handling code here:
        this.dispose();
        Menu menu = new Menu();
        menu.setVisible(true);
    }//GEN-LAST:event_jButtonMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gioco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gioco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gioco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gioco.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonMenu;
    private javax.swing.JButton jButtonReset;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelGrigliaBot;
    private javax.swing.JPanel jPanelGrigliaGiocatore;
    private javax.swing.JScrollPane jScrollPaneSideBar;
    private javax.swing.JTextArea jTextAreaSideBar;
    // End of variables declaration//GEN-END:variables
}
